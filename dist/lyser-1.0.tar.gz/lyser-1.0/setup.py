from setuptools import setup, find_packages

setup(
    name='lyser',
    version='1.0',
    packages=find_packages(),
    install_requires=[],
    entry_points={},
    test_suite='tests',
)
